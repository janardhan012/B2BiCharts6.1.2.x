# What's new in Helm Charts Version 2.1.12 for IBM Sterling File Gateway Enterprise Edition v6.1.2.8
* Support for configuring topology spread constraints for application pods
* Support for configuring tolerations for application pods
* Support for configuring additional annotations and loadBalancer IP for services
* Support for configuring truststore and keystore certificates using Kubernetes secrets for Database, IBM MQ and Liberty SSL connections. Additional certificates and configuration maps can also be mapped now to application pods using extra secrets and configmaps configurations.
* Security fixes
* Tech stack upgrades
    Red Hat UBI base image version 9.7.x
    Red Hat OpenShift Container Platform 4.17, 4.18, 4.19 and 4.20 or later fixes
    Kubernetes versions >=1.31 and < =1.35
    Helm version 3.19.x


# Breaking Changes
Rolling upgrades for product version v6.1.0.0 will be supported but for product versions earlier than v6.1.0.0 installed using IIM, Docker or Certified Container will not be supported.

# Documentation
Check the README file provided with the chart for detailed installation instructions.

# Fixes
N/A

# Prerequisites
Please refer prerequisites section from README.md

# Version History

| Chart | Date | Kubernetes Version Required | Breaking Changes | Details |
| ----- | ---- | --------------------------- | ---------------- | ------- |
| 2.0.1   | December 18, 2020 | >=1.14.6 | N  | Fix pack release upgrade for IBM Sterling File Gateway Certified Containers |
| 2.0.2   | March 19, 2021 | >=1.14.6 | N  | Fix pack release upgrade for IBM Sterling File Gateway Certified Containers |
| 2.0.3   | June 29, 2021 | >=1.17 | N  | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers |
| 2.0.4   | Novemeber 10, 2021 | >=1.17 | N  | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers |
| 2.0.5   | January 14, 2022 | >=1.17 | N  | IFix release upgrade for IBM Sterling B2B Integrator Certified Containers |
| 2.0.6   | May 13, 2022 | >=1.17 | N  | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers |
| 2.1.1   | Dec 16, 2022 | >=1.21 | N  | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers |
| 2.1.2   | Mar 03, 2022 | >=1.23 | N  | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers |
| 2.1.3   | Mar 27, 2023  | >=1.23 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
| 2.1.4   | Jun 31, 2023  | >=1.23 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
| 2.1.5   | Jan 31, 2024  | >=1.26 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
| 2.1.6   | Jan 31, 2024  | >=1.26 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
| 2.1.7   | Sept 31, 2024  | >=1.27 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
| 2.1.9   | Oct 31, 2024  | >=1.27 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
| 2.1.12 | Dec 26, 2025 | >=1.31 | N | Fix pack release upgrade for IBM Sterling B2B Integrator Certified Containers | Y |
